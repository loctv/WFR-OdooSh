# -*- coding: utf-8 -*-
# Part of AppJetty. See LICENSE file for full copyright and licensing details.

from . import slider
from . import res_partner
from . import product_category
from . import event
from . import website
from . import theme_ir_ui
from . import theme_custom
